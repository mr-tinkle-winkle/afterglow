"""
SQLite database for clip configs, the local/uploaded video library, and tags.

One DB file, lives next to the config: ~/.config/afterglow/library.db
(Not inside ~/Videos/Clips, so the clips folder can be a plain folder of
media files with nothing weird in it — easier to browse, sync, back up.)
"""
from __future__ import annotations

import sqlite3
from pathlib import Path
from contextlib import contextmanager

from .config import CONFIG_DIR

DB_PATH = CONFIG_DIR / "library.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS clip_configs (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT NOT NULL,
    length_seconds  INTEGER NOT NULL,
    sound_path      TEXT,                  -- NULL/empty = use default sound
    hotkey          TEXT,                  -- serialized combo, e.g. "ctrl+shift+f9"
    sort_order      INTEGER NOT NULL DEFAULT 0,
    overlay_enabled         INTEGER NOT NULL DEFAULT 0,      -- capture Puppetry's input overlay with this clip type
    overlay_pieces          TEXT NOT NULL DEFAULT '["keyboard","mouse"]',   -- JSON list of pieces to render
    overlay_visible_default INTEGER NOT NULL DEFAULT 1,      -- overlay starts shown in previewer/editor
    overlay_offset_ms       REAL NOT NULL DEFAULT 0,         -- timing calibration (+ later, - earlier)
    overlay_placements      TEXT NOT NULL DEFAULT '{}',      -- JSON {piece: {x,y,w,rotation,visible}} per-piece overrides
    indicator_colors        TEXT NOT NULL DEFAULT '{}',      -- clip indicator: JSON {part: "#rrggbb"} ({} = defaults)
    indicator_icon_path     TEXT NOT NULL DEFAULT '',        -- clip indicator: custom icon image ('' = none)
    indicator_clap_sound    TEXT NOT NULL DEFAULT '',        -- clip indicator: clap sound ('' = the clip type's / global clip sound)
    youtube_playlist        TEXT NOT NULL DEFAULT ''         -- YouTube playlist name uploads of this type go into ('' = none)
);

CREATE TABLE IF NOT EXISTS videos (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    filename        TEXT NOT NULL,
    path            TEXT NOT NULL UNIQUE,   -- absolute path to the working file on disk
    title           TEXT NOT NULL,
    description     TEXT NOT NULL DEFAULT '',
    duration_sec    REAL,                   -- NULL until probed
    created_at      TEXT NOT NULL,          -- ISO timestamp, clip capture time
    clip_config_id  INTEGER,                -- which clip option produced this (nullable, e.g. manual import)
    has_edit        INTEGER NOT NULL DEFAULT 0,   -- 1 if a trim has been committed
    backup_path     TEXT,                   -- pre-edit copy, for undo. NULL if no pending undo.
    youtube_video_id TEXT,                  -- NULL until uploaded
    youtube_privacy TEXT,                   -- 'unlisted' | 'public' | 'private', NULL if not uploaded
    favorite        INTEGER NOT NULL DEFAULT 0,   -- 1 if starred as a favorite clip
    -- YouTube upload (see afterglow/youtube/). youtube_video_id is set only once the upload is
    -- done; while it runs the id lives in youtube_pending_id.
    upload_state    TEXT,                   -- NULL | queued | uploading | processing | done | failed
    upload_error    TEXT,                   -- last failure, shown on the card / in the queue
    youtube_pending_id TEXT,                -- the id Studio showed while the upload runs
    uploaded_at     TEXT,                   -- ISO timestamp the upload finished
    youtube_title   TEXT,                   -- what was sent to YouTube (may differ from title)
    youtube_description TEXT,
    youtube_playlist TEXT,
    thumb_cache_path TEXT,                  -- cached i.ytimg.com thumbnail (the Uploaded tab's card art)
    file_size_bytes INTEGER,                -- remembered for the description template after the file is gone
    local_deleted   INTEGER NOT NULL DEFAULT 0,   -- 1 = the local file was moved to the trash after uploading
    FOREIGN KEY (clip_config_id) REFERENCES clip_configs(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS filter_categories (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL UNIQUE COLLATE NOCASE
);

CREATE TABLE IF NOT EXISTS tags (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL UNIQUE COLLATE NOCASE,
    icon_path   TEXT,                    -- optional icon shown above/below clip thumbnails
    category_id INTEGER,                 -- NULL = uncategorized, shown loose in the Filters dropdown
    outline_color TEXT,                  -- optional per-tag override for Filter Outline's color (NULL = use the global default)
    FOREIGN KEY (category_id) REFERENCES filter_categories(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS video_tags (
    video_id    INTEGER NOT NULL,
    tag_id      INTEGER NOT NULL,
    PRIMARY KEY (video_id, tag_id),
    FOREIGN KEY (video_id) REFERENCES videos(id) ON DELETE CASCADE,
    FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_video_tags_tag ON video_tags(tag_id);
CREATE INDEX IF NOT EXISTS idx_video_tags_video ON video_tags(video_id);
"""

# Clip config names need to be unique, case-insensitively, since they're
# used as the stable identifier for hotkey-triggered CLI invocations
# (e.g. `cli.py trigger --name Ace`) -- a system keybind shouldn't have to
# know a numeric DB id. This is a separate CREATE UNIQUE INDEX (rather than
# an inline UNIQUE column constraint) so it can be applied to a database
# that was already created before this constraint existed, without an
# ALTER TABLE migration.
UNIQUE_NAME_INDEX = (
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_clip_configs_name "
    "ON clip_configs(name COLLATE NOCASE)"
)


def _has_column(conn: sqlite3.Connection, table: str, column: str) -> bool:
    rows = conn.execute(f"PRAGMA table_info({table})").fetchall()
    return any(r["name"] == column for r in rows)


def _migrate_columns(conn: sqlite3.Connection) -> None:
    """Add columns introduced after the initial schema to a pre-existing
    DB file. CREATE TABLE IF NOT EXISTS (above) only affects DBs that
    don't have the table at all yet -- an already-existing table needs
    an explicit ALTER TABLE to pick up new columns."""
    if not _has_column(conn, "videos", "favorite"):
        conn.execute("ALTER TABLE videos ADD COLUMN favorite INTEGER NOT NULL DEFAULT 0")
    if not _has_column(conn, "tags", "icon_path"):
        conn.execute("ALTER TABLE tags ADD COLUMN icon_path TEXT")
    if not _has_column(conn, "tags", "category_id"):
        conn.execute("ALTER TABLE tags ADD COLUMN category_id INTEGER REFERENCES filter_categories(id) ON DELETE SET NULL")
    for col, ddl in (
        ("overlay_enabled", "INTEGER NOT NULL DEFAULT 0"),
        ("overlay_pieces", "TEXT NOT NULL DEFAULT '[\"keyboard\",\"mouse\"]'"),
        ("overlay_visible_default", "INTEGER NOT NULL DEFAULT 1"),
        ("overlay_offset_ms", "REAL NOT NULL DEFAULT 0"),
        ("overlay_placements", "TEXT NOT NULL DEFAULT '{}'"),
        ("indicator_colors", "TEXT NOT NULL DEFAULT '{}'"),
        ("indicator_icon_path", "TEXT NOT NULL DEFAULT ''"),
        ("indicator_clap_sound", "TEXT NOT NULL DEFAULT ''"),
        ("youtube_playlist", "TEXT NOT NULL DEFAULT ''"),
    ):
        if not _has_column(conn, "clip_configs", col):
            conn.execute(f"ALTER TABLE clip_configs ADD COLUMN {col} {ddl}")
    if not _has_column(conn, "tags", "outline_color"):
        conn.execute("ALTER TABLE tags ADD COLUMN outline_color TEXT")
    for col, ddl in (
        ("upload_state", "TEXT"),
        ("upload_error", "TEXT"),
        ("youtube_pending_id", "TEXT"),
        ("uploaded_at", "TEXT"),
        ("youtube_title", "TEXT"),
        ("youtube_description", "TEXT"),
        ("youtube_playlist", "TEXT"),
        ("thumb_cache_path", "TEXT"),
        ("file_size_bytes", "INTEGER"),
        ("local_deleted", "INTEGER NOT NULL DEFAULT 0"),
    ):
        if not _has_column(conn, "videos", col):
            conn.execute(f"ALTER TABLE videos ADD COLUMN {col} {ddl}")


def init_db() -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with get_conn() as conn:
        conn.executescript(SCHEMA)
        _migrate_columns(conn)
        try:
            conn.execute(UNIQUE_NAME_INDEX)
        except sqlite3.IntegrityError:
            # Pre-existing DB already has duplicate clip config names.
            # Don't hard-fail app startup over this -- surface it instead,
            # since dedup requires a human decision (which one keeps the name).
            dupes = conn.execute(
                """SELECT name, COUNT(*) c FROM clip_configs
                   GROUP BY name COLLATE NOCASE HAVING c > 1"""
            ).fetchall()
            names = ", ".join(f"'{r['name']}'" for r in dupes)
            print(
                f"Warning: duplicate clip config names found ({names}). "
                f"Rename one of each pair -- clip config names must be unique "
                f"to be used with `trigger --name`."
            )


@contextmanager
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


if __name__ == "__main__":
    init_db()
    print(f"DB initialized at {DB_PATH}")
