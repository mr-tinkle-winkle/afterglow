"""
Embedded video preview/playback for the Editor page, via mpv's OpenGL
render API -- deliberately NOT mpv's window-ID ("wid") embedding.

wid-based embedding is an X11-specific mechanism: it works by handing mpv
a raw X11 window ID to draw into. It does not work when Qt is running as
a native Wayland client, because Wayland has no equivalent concept of
"embed into this arbitrary window handle" -- window composition works
fundamentally differently there. Since fixing the earlier Qt
platform-plugin loading issue means this app can now actually run as a
native Wayland client (rather than failing to start at all), wid
embedding is not a safe bet here. mpv's render API sidesteps the question
entirely: it just draws into an OpenGL context Qt hands it, and doesn't
care what's ultimately hosting that context on either backend.

NOTE: the actual on-screen rendering in this widget could not be tested
in the sandbox this was built in (no display/GPU available there) --
what WAS verified directly: mpv's underlying playback control (load,
pause/play, absolute seeking, position/duration tracking via
observe_property) all work correctly using mpv's headless vo=null output,
which exercises everything except the actual GL draw calls in paintGL().
If the video area renders blank on your machine despite controls working,
that narrows the problem specifically to the OpenGL/proc-address wiring
in initializeGL()/paintGL() below, not the playback logic around it.
"""
from __future__ import annotations

import locale

from PySide6.QtCore import Signal, QTimer, Qt
from PySide6.QtGui import QOpenGLContext
from PySide6.QtOpenGLWidgets import QOpenGLWidget

import mpv


def _get_proc_address(_ctx, name: bytes) -> int:
    glctx = QOpenGLContext.currentContext()
    if glctx is None:
        return 0
    addr = glctx.getProcAddress(name.decode("utf-8"))
    return int(addr) if addr else 0


class MpvVideoWidget(QOpenGLWidget):
    """
    Small GUI-friendly surface over mpv -- editor_page.py talks to this,
    not to mpv's own API directly, so mpv-specific details stay contained
    in one place.
    """

    position_changed = Signal(float)   # current playback position, seconds
    duration_known = Signal(float)     # fires once when duration becomes available
    playback_ended = Signal()
    clicked = Signal()                 # left-click on the video, or Space while it has focus -- toggle play/pause

    def __init__(self, parent=None):
        super().__init__(parent)
        # 120, not 300 -- this floor propagates up through EditorPage into
        # MainWindow's own minimum height, and 300 was the single largest
        # remaining contributor once Settings became scrollable.
        self.setMinimumHeight(120)
        # StrongFocus (not the QOpenGLWidget default of NoFocus) so this
        # widget can actually receive the Space key and so a click can
        # grab focus for it -- both needed for the click/Space-to-play
        # handlers below to work at all.
        self.setFocusPolicy(Qt.StrongFocus)
        self._first_load_done = False

        # libmpv requires the process's LC_NUMERIC to be exactly "C" --
        # confirmed against a real crash: Qt's own QApplication changes
        # the C library's locale internally based on the desktop
        # environment's settings, and if that leaves LC_NUMERIC using a
        # non-"." decimal separator (many non-English locales use ","),
        # libmpv's internal numeric parsing breaks in ways that can
        # segfault rather than just misbehave -- this is documented
        # directly in mpv's own client API and is a well-known gotcha for
        # anything embedding libmpv. Only LC_NUMERIC is touched here, not
        # the whole locale -- this doesn't affect date formatting, text,
        # or anything else the rest of the app relies on.
        locale.setlocale(locale.LC_NUMERIC, "C")

        self._mpv = mpv.MPV(
            vo="libmpv", loglevel="error",
            # Without this, mpv's default at end-of-file is to stop and
            # effectively unload the file rather than just pausing on the
            # last frame -- which is why playback became impossible once
            # you reached the end: is_paused would still read False (mpv
            # never actually set pause=True, it just stopped), so Space/
            # click would toggle it INTO pause instead of starting
            # playback, and even a subsequent seek()+play() had nothing
            # loaded to act on. keep_open pauses at the last frame
            # instead, leaving the file loaded so seek+play afterward
            # behaves the same as it would from any other paused state.
            keep_open="yes",
        )
        self._render_ctx: "mpv.MpvRenderContext | None" = None
        self._duration_reported = False

        # Stored as an instance attribute, not a throwaway inline
        # expression in initializeGL() -- ctypes function-pointer callback
        # objects need something on the Python side to keep them alive for
        # as long as the C/mpv side might call them. If nothing holds a
        # reference, Python can garbage-collect the wrapper while mpv
        # still has the raw function pointer, producing an intermittent,
        # very hard-to-diagnose crash later. Keeping it on self for the
        # widget's whole lifetime avoids that class of bug entirely.
        self._get_proc_address_cfunc = mpv.MpvGlGetProcAddressFn(_get_proc_address)

        # mpv's property-observer callbacks fire on mpv's own internal
        # thread, not Qt's. Signals are emitted directly from that thread
        # below -- Qt's signal/slot mechanism automatically marshals a
        # cross-thread emission onto the RECEIVER's event loop (Qt::Auto-
        # Connection becomes queued when sender and receiver live in
        # different threads), which only requires an event loop on the
        # receiving side (always true here -- it's the main GUI thread).
        #
        # An earlier version of this wrapped each emit in
        # QTimer.singleShot(0, ...), on the assumption that this was needed
        # to safely bounce onto the Qt thread. That was itself the actual
        # bug behind "video renders but the clock/scrubber never move":
        # QTimer.singleShot(msec, callback) requires a running Qt event
        # loop on the thread that CALLS it, and mpv's internal callback
        # thread doesn't have one, so those timers were silently created
        # and never fired. Confirmed directly with a headless repro
        # (vo=null, no GL/display needed): the QTimer.singleShot version
        # received 0 position updates across a 3.5s real clip; emitting
        # the signal directly received 30/30. The GL render path
        # (update_cb = self.update, below) was unaffected by this bug
        # because QWidget.update() posts its event directly rather than
        # going through a timer that needs an event loop on the caller's
        # side -- which is also why video could render while the time
        # display and scrubber stayed frozen at 0:00.
        self._mpv.observe_property("time-pos", self._on_time_pos)
        self._mpv.observe_property("duration", self._on_duration)
        self._mpv.observe_property("eof-reached", self._on_eof)

    def initializeGL(self) -> None:
        self._render_ctx = mpv.MpvRenderContext(
            self._mpv, "opengl",
            opengl_init_params={
                # Must be an actual ctypes function pointer, not a plain
                # Python callable -- python-mpv's MpvOpenGLInitParams
                # structure declares this field's type as
                # MpvGlGetProcAddressFn (a CFUNCTYPE), and assigning a bare
                # Python function to a ctypes Structure field of function-
                # pointer type doesn't implicitly convert it. This was the
                # actual crash: "expected CFunctionType instance, got
                # function". Confirmed directly against python-mpv 1.0.8's
                # source (mpv.py) before applying this.
                "get_proc_address": self._get_proc_address_cfunc,
            },
        )
        self._render_ctx.update_cb = self.update

        # Covers a startup race: Qt only calls initializeGL() lazily, on
        # this widget's first actual paint -- which can land either before
        # or after load() has already told mpv to start decoding.
        # update_cb is what mpv calls to say "a new frame is ready,
        # please repaint", but if mpv had already produced (and tried to
        # announce) its first frame before update_cb existed above, that
        # one announcement is simply lost -- nothing was listening yet.
        # Combined with the matching self.update() scheduled from load()
        # below (for the opposite ordering, where GL isn't initialized
        # yet when load() runs), this means at least one repaint always
        # happens shortly after BOTH "GL is ready" and "mpv has a frame"
        # are true, regardless of which happened first. This is the
        # mechanism behind the reported first-play black screen: video
        # controls (audio, position/duration, the scrubber) were
        # confirmed unaffected since they don't go through update_cb at
        # all, only the actual GL draw was ever missing.
        self.update()

    def paintGL(self) -> None:
        if self._render_ctx is None:
            return
        factor = self.devicePixelRatioF()
        self._render_ctx.render(
            flip_y=True,
            opengl_fbo={
                "w": int(self.width() * factor),
                "h": int(self.height() * factor),
                "fbo": self.defaultFramebufferObject(),
            },
        )

    # ------------------------------------------------------------ playback control

    def load(self, path: str, overlay_files: "list[str] | None" = None, overlay_graph: str = "") -> None:
        """Load `path`. `overlay_files` / `overlay_graph` are the input
        overlay's pieces (external transparent videos) and the lavfi-complex
        graph that composites them (see overlay_support.preview_graph); both
        are RESET on every load, so a clip without an overlay never inherits
        the previous clip's."""
        self._duration_reported = False
        self.set_overlay(overlay_files or [], overlay_graph if overlay_files else "")
        self._mpv.play(path)
        self._mpv.pause = True  # load paused -- Editor decides whether/when to auto-play

        if not self._first_load_done:
            self._first_load_done = True
            # Reported as still showing a black screen on the very first
            # video played after opening the GUI specifically (not on
            # subsequent loads), even after two rounds of repaint/seek-
            # based mitigations aimed at a suspected GL-init/render-
            # context timing race. Simplest fix, suggested directly:
            # just request the load a SECOND time. Whatever combination
            # of timing dropped the first request's frame, a second
            # request shortly after lands once all of that has already
            # settled. Only done for the first video of the widget's
            # lifetime -- later loads aren't affected, and reloading
            # every time would just add a pointless flicker/reset.
            QTimer.singleShot(150, lambda p=path: self._reload_first_video(p))

    def set_overlay(self, files: "list[str]", graph: str) -> None:
        """Set the overlay's external files (read when a file is loaded)
        and the lavfi-complex graph (can change any time -- the previewer's
        on/off toggle just swaps the graph). An empty graph = no overlay."""
        try:
            self._mpv["external-files"] = list(files)
        except Exception:  # noqa: BLE001
            pass
        self.set_overlay_graph(graph)

    def set_overlay_graph(self, graph: str) -> None:
        try:
            self._mpv["lavfi-complex"] = graph or ""
        except Exception:  # noqa: BLE001
            pass

    def _reload_first_video(self, path: str) -> None:
        # Preserves whatever play/pause state was ACTUALLY in effect
        # right before this fires, instead of unconditionally forcing
        # pause=True -- the previous version did that unconditionally,
        # which is exactly why the video previewer's autoplay-on-open
        # "started playing for a moment and then stopped": load()
        # itself always sets pause=True, VideoPreviewDialog then calls
        # play() immediately afterward (synchronously, same event-loop
        # tick), so by the time THIS 150ms-later callback ran, the
        # real desired state was already "playing" -- but this method
        # blindly reset it back to paused anyway, undoing that. Reading
        # self._mpv.pause right here instead of hardcoding a value
        # means whatever the caller's own play()/pause() calls already
        # established (Editor's default paused-on-load, or the
        # previewer's explicit play()) survives this reload exactly as
        # it was, since this is only meant to work around a black-
        # screen render bug, not to have an opinion of its own about
        # play state.
        was_paused = self._mpv.pause
        self._mpv.play(path)
        self._mpv.pause = was_paused
        self.update()

    def play(self) -> None:
        self._mpv.pause = False

    def pause(self) -> None:
        self._mpv.pause = True

    @property
    def is_paused(self) -> bool:
        return bool(self._mpv.pause)

    def seek(self, position_sec: float) -> None:
        self._mpv.seek(position_sec, reference="absolute", precision="exact")

    def frame_step(self) -> None:
        """Advances exactly one frame forward, pausing playback first if
        it was running -- mpv's own "frame-step" command already does
        this (steps then pauses), matching what frame-by-frame nudging
        should do regardless of whether the video was playing when the
        nudge happened."""
        self._mpv.frame_step()

    def frame_back_step(self) -> None:
        """The reverse of frame_step() -- one frame backward."""
        self._mpv.frame_back_step()

    def set_volume(self, value: int) -> None:
        """Client-side playback volume only (0-100) -- akin to a YouTube
        player's volume control, this affects nothing about the saved
        video file, only how loud THIS preview plays back."""
        self._mpv.volume = max(0, min(100, value))

    def set_speed(self, multiplier: float) -> None:
        """Preview-only playback speed (e.g. 0.1 = 10% speed) -- a plain
        property on the live mpv instance, same as volume above: affects
        nothing about the saved file or any future trim/export, purely
        how fast THIS preview plays back right now."""
        self._mpv.speed = max(0.01, multiplier)

    # ------------------------------------------------------------ click/keyboard play-pause

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.LeftButton:
            self.setFocus()  # so Space keeps working right after a click, without a separate step
            self.clicked.emit()

    def keyPressEvent(self, event) -> None:
        if event.key() == Qt.Key_Space:
            self.clicked.emit()
        else:
            super().keyPressEvent(event)

    def shutdown(self) -> None:
        """Call before the widget/app is destroyed -- mpv holds real
        native resources (decoder threads, GL context state) that need
        explicit teardown, not just Python garbage collection."""
        if self._render_ctx is not None:
            self._render_ctx.free()
            self._render_ctx = None
        self._mpv.terminate()

    # ------------------------------------------------------------ mpv callbacks (foreign thread)

    def _on_time_pos(self, _name, value) -> None:
        if value is not None:
            self.position_changed.emit(value)

    def _on_duration(self, _name, value) -> None:
        if value is not None and not self._duration_reported:
            self._duration_reported = True
            self.duration_known.emit(value)

    def _on_eof(self, _name, value) -> None:
        if value:
            self.playback_ended.emit()
