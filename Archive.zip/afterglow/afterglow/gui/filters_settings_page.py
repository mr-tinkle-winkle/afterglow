"""
Settings > Filters: everything about how tags/filters are displayed and
auto-applied, split from the main SettingsPage (settings_page.py) since
it's a self-contained cluster of controls with its own save/load needs.

Three groups:
  - Tag icons: assign/clear an icon per tag, and rename a tag (moved
    here from a right-click-in-the-dropdown interaction -- see this
    module's note on FilterCheckBox in library_page.py for why).
  - Display: the three global display toggles/dropdown that control how
    those icons (and filter names) show up above library thumbnails.
  - Auto Add Filter: rules that auto-tag newly captured clips based on
    which application is open/focused at capture time (see
    autofilter.py for the detection side; this page only edits the
    rule list itself).
"""
from __future__ import annotations

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QComboBox, QScrollArea, QFrame, QLineEdit,
    QFormLayout, QToolButton,
    QMenu, QWidgetAction, QDialog, QButtonGroup, QStackedWidget,
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QPixmap
from pathlib import Path

from .. import library
from .. import config as config_module
from .. import autofilter
from .custom_line_edit import CustomLineEdit
from .custom_group_box import CustomGroupBox
from .custom_combo_style import combo_box_stylesheet
from .smooth_scroll_area import SmoothScrollArea
from .custom_button import CustomButton
from .custom_combo_box import CustomComboBox, paint_dropdown_field
from .custom_checkbox import CustomCheckBox
from .themed_dialogs import get_color, get_open_file_name, get_text
from .themed_frame import ThemedFrame
from .custom_message_dialog import show_message

_ICON_LOCATIONS = [
    ("Above", "above"),
    ("Below", "below"),
    ("Vertical Tiling Left", "vtile_left"),
    ("Vertical Tiling Right", "vtile_right"),
]

_NEW_CATEGORY_DATA = "__new_category__"


class _TagIconRow(QFrame):
    def __init__(self, tag_id: int, tag_name: str, icon_path: str | None,
                 category_id: int | None, categories: list[tuple[int, str]],
                 outline_color: str | None = None, parent=None):
        super().__init__(parent)
        self.tag_id = tag_id
        self.tag_name = tag_name
        self.icon_path = icon_path or ""
        self.outline_color = outline_color or ""

        row = QHBoxLayout(self)
        row.setContentsMargins(2, 2, 2, 2)

        self.name_label = QLabel(tag_name)
        row.addWidget(self.name_label, stretch=1)

        self.category_combo = CustomComboBox()
        self.category_combo.setStyleSheet(combo_box_stylesheet(config_module.load_readonly().appearance))
        self._populate_category_combo(categories, category_id)
        self.category_combo.currentIndexChanged.connect(self._on_category_changed)
        row.addWidget(self.category_combo)

        self.icon_thumb = QLabel()
        self.icon_thumb.setFixedSize(24, 24)
        row.addWidget(self.icon_thumb)

        self.icon_preview = QLabel(self._icon_summary())
        self.icon_preview.setStyleSheet("color: gray;")
        row.addWidget(self.icon_preview)
        self._update_icon_thumb()

        set_icon_btn = CustomButton("Set Icon...")
        set_icon_btn.clicked.connect(self._browse_icon)
        row.addWidget(set_icon_btn)

        clear_btn = CustomButton("Clear Icon")
        clear_btn.clicked.connect(self._clear_icon)
        row.addWidget(clear_btn)

        # Filter Outline's per-tag color override (Settings > General
        # for the global default/toggle) -- empty means "use the
        # global default", same convention as icon_path above.
        self.outline_color_edit = CustomLineEdit(self.outline_color)
        self.outline_color_edit.setPlaceholderText("(default)")
        self.outline_color_edit.setMaxLength(9)
        self.outline_color_edit.setFixedWidth(80)
        row.addWidget(self.outline_color_edit)
        outline_pick_btn = CustomButton("Outline...")
        outline_pick_btn.clicked.connect(self._pick_outline_color)
        row.addWidget(outline_pick_btn)

        rename_btn = CustomButton("Rename")
        rename_btn.clicked.connect(self._rename)
        row.addWidget(rename_btn)

    def _populate_category_combo(self, categories: list[tuple[int, str]], selected_id: int | None) -> None:
        self.category_combo.blockSignals(True)
        self.category_combo.clear()
        self.category_combo.addItem("(no category)", None)
        for cat_id, cat_name in categories:
            self.category_combo.addItem(cat_name, cat_id)
        self.category_combo.addItem("+ New Category...", _NEW_CATEGORY_DATA)
        index = self.category_combo.findData(selected_id)
        self.category_combo.setCurrentIndex(index if index >= 0 else 0)
        self.category_combo.blockSignals(False)

    def _on_category_changed(self, _index: int) -> None:
        data = self.category_combo.currentData()
        if data == _NEW_CATEGORY_DATA:
            name, ok = get_text(self, "New Category", "Category name:")
            name = name.strip()
            if not ok or not name:
                # Revert to "(no category)" rather than leaving the
                # "+ New Category..." entry selected.
                self.category_combo.setCurrentIndex(0)
                return
            new_id = library.create_category(name)
            library.set_tag_category(self.tag_id, new_id)
            self._populate_category_combo(library.all_categories(), new_id)
        else:
            library.set_tag_category(self.tag_id, data)

    def _icon_summary(self) -> str:
        return self.icon_path.rsplit("/", 1)[-1] if self.icon_path else "(no icon)"

    def _update_icon_thumb(self) -> None:
        """A real scaled preview of the chosen icon file, next to its
        filename -- per the direct request, since the filename alone
        doesn't show what the icon actually looks like."""
        if self.icon_path and Path(self.icon_path).exists():
            pixmap = QPixmap(self.icon_path)
            if not pixmap.isNull():
                self.icon_thumb.setPixmap(
                    pixmap.scaled(24, 24, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                )
                return
        self.icon_thumb.clear()

    def _browse_icon(self) -> None:
        path, _ = get_open_file_name(
            self, "Choose Icon", "", "Images (*.png *.jpg *.jpeg *.svg *.ico);;All Files (*)"
        )
        if path:
            self.icon_path = path
            self.icon_preview.setText(self._icon_summary())
            self._update_icon_thumb()

    def _clear_icon(self) -> None:
        self.icon_path = ""
        self.icon_preview.setText(self._icon_summary())
        self._update_icon_thumb()

    def _pick_outline_color(self) -> None:
        current = QColor(self.outline_color_edit.text().strip())
        if not current.isValid():
            current = QColor("#3669a0")
        color = get_color(current, self, "Choose Outline Color")
        if color.isValid():
            self.outline_color_edit.setText(color.name())

    def _rename(self) -> None:
        new_name, ok = get_text(self, "Rename Filter", "Filter name:", text=self.tag_name)
        new_name = new_name.strip()
        if not ok or not new_name or new_name == self.tag_name:
            return
        try:
            library.rename_tag(self.tag_id, new_name)
        except library.LibraryError as e:
            show_message(self, "Rename Failed", str(e))
            return
        self.tag_name = new_name
        self.name_label.setText(new_name)


class _MultiFilterSelectButton(QToolButton):
    """A dropdown of every existing filter, each with its own checkbox,
    letting an Auto Add Filter rule apply several filters at once (the
    "filter(s) of choice" for that rule) -- replaces a single free-text
    filter-name field."""

    def __init__(self, selected: list[str], parent=None):
        super().__init__(parent)
        self.setPopupMode(QToolButton.InstantPopup)
        self.setCursor(Qt.PointingHandCursor)
        self._hover = False
        self._selected: list[str] = list(selected)
        self.refresh_options()

    def refresh_options(self) -> None:
        from .video_card import _menu_stylesheet
        menu = QMenu(self)
        menu.setStyleSheet(_menu_stylesheet(config_module.load_readonly().appearance))
        all_tags = library.all_known_tags()
        if not all_tags:
            action = menu.addAction("(no filters yet)")
            action.setEnabled(False)
        for tag in all_tags:
            checkbox = CustomCheckBox(tag, menu)
            checkbox.setChecked(tag in self._selected)
            checkbox.toggled.connect(lambda checked, t=tag: self._toggle(t, checked))
            action = QWidgetAction(menu)
            action.setDefaultWidget(checkbox)
            menu.addAction(action)
        self.setMenu(menu)
        self._update_text()

    def _toggle(self, tag: str, checked: bool) -> None:
        if checked and tag not in self._selected:
            self._selected.append(tag)
        elif not checked and tag in self._selected:
            self._selected.remove(tag)
        self._update_text()

    def _update_text(self) -> None:
        self.setText(", ".join(self._selected) if self._selected else "Choose filter(s)...")

    # Drawn as the same dropdown field as CustomComboBox rather than a
    # native tool button with a menu arrow.
    def enterEvent(self, event) -> None:
        self._hover = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        self._hover = False
        self.update()
        super().leaveEvent(event)

    def paintEvent(self, event) -> None:
        from PySide6.QtGui import QPainter
        p = QPainter(self)
        paint_dropdown_field(p, self, self.text(), open_=self.isDown(),
                             hover=getattr(self, "_hover", False), focused=self.hasFocus())
        p.end()

    def sizeHint(self):
        s = super().sizeHint()
        s.setHeight(max(s.height(), 30))
        return s

    @property
    def selected_tags(self) -> list[str]:
        return list(self._selected)


class _AutoFilterRow(ThemedFrame):
    def __init__(self, tag_names: list[str] | None = None, app_match: str = "",
                 mode: str = "open", parent=None):
        super().__init__(parent)
        row = QHBoxLayout(self)
        row.setContentsMargins(4, 4, 4, 4)

        self.filter_select = _MultiFilterSelectButton(tag_names or [])
        row.addWidget(self.filter_select, stretch=1)

        # Editable combo, not a plain text field: it doubles as a
        # dropdown of currently-running process names (so a match
        # string can be picked with a click instead of typed blind) and
        # a normal typable box, since the app you want to match might
        # not be running yet when this row is being set up.
        self.app_combo = CustomComboBox()
        self.app_combo.setStyleSheet(combo_box_stylesheet(config_module.load_readonly().appearance))
        self.app_combo.setEditable(True)
        self.app_combo.setPlaceholderText("App/process name match")
        self._refresh_running_apps(keep_text=app_match)
        row.addWidget(self.app_combo, stretch=1)

        refresh_apps_btn = CustomButton("\u21bb")  # "↻"
        refresh_apps_btn.setToolTip("Refresh running app list")
        refresh_apps_btn.setFixedWidth(28)
        refresh_apps_btn.clicked.connect(lambda: self._refresh_running_apps())
        row.addWidget(refresh_apps_btn)

        self.mode_combo = CustomComboBox()
        self.mode_combo.setStyleSheet(combo_box_stylesheet(config_module.load_readonly().appearance))
        self.mode_combo.addItem("While app is open", "open")
        self.mode_combo.addItem("Only while app is focused", "focused")
        index = self.mode_combo.findData(mode)
        self.mode_combo.setCurrentIndex(index if index >= 0 else 0)
        row.addWidget(self.mode_combo)

        self.remove_btn = CustomButton("Remove")
        row.addWidget(self.remove_btn)

    def _refresh_running_apps(self, keep_text: str | None = None) -> None:
        current_text = keep_text if keep_text is not None else self.app_combo.currentText()
        self.app_combo.clear()
        self.app_combo.addItems(autofilter.list_running_process_display_names())
        self.app_combo.setCurrentText(current_text)  # still typable -- doesn't have to match a list entry

    def to_rule(self) -> config_module.AutoFilterRule:
        return config_module.AutoFilterRule(
            tag_names=self.filter_select.selected_tags,
            app_match=self.app_combo.currentText().strip(),
            mode=self.mode_combo.currentData(),
        )


class FiltersSettingsPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._settings = config_module.load()
        self._tag_rows: list[_TagIconRow] = []
        self._auto_rows: list[_AutoFilterRow] = []

        outer = QVBoxLayout(self)

        # Same CustomButton + QStackedWidget tab pattern SettingsPage's
        # own top-level tabs already use, replacing the native
        # QTabWidget this used to be -- "filter page headers (Filters &
        # Auto Add Filters)" reported directly as one of the few
        # remaining non-custom things in Settings.
        TAB_BUTTON_SPACING = 12
        self._filters_stack = QStackedWidget()
        tab_button_group = QButtonGroup(self)
        tab_button_group.setExclusive(True)
        tab_header = QHBoxLayout()
        tab_header.setSpacing(0)

        def _add_tab(label: str, page: QWidget) -> None:
            index = self._filters_stack.count()
            self._filters_stack.addWidget(page)
            btn = CustomButton(label)
            btn.setCheckable(True)
            btn.setMinimumHeight(36)
            tab_button_group.addButton(btn, index)
            if tab_header.count() > 0:
                tab_header.addSpacing(TAB_BUTTON_SPACING)
            tab_header.addWidget(btn)
            if index == 0:
                btn.setChecked(True)

        tab_button_group.idClicked.connect(self._filters_stack.setCurrentIndex)

        _add_tab("Filters", self._build_filters_tab())
        _add_tab("Auto Add Filter", self._build_auto_filter_tab())

        tab_header.addStretch(1)
        outer.addLayout(tab_header)
        outer.addWidget(self._filters_stack, stretch=1)

    # ------------------------------------------------------------ Filters tab

    def _build_filters_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        display_group = CustomGroupBox("Display")
        form = display_group.make_layout(QFormLayout)

        self.show_names_check = CustomCheckBox()
        self.show_names_check.setChecked(self._settings.filter_display.show_filter_names)
        form.addRow("Show Filter Names under Clips:", self.show_names_check)

        self.show_icons_check = CustomCheckBox()
        self.show_icons_check.setChecked(self._settings.filter_display.show_filter_icons)
        form.addRow("Show Filter Icons:", self.show_icons_check)

        self.icon_location_combo = CustomComboBox()
        self.icon_location_combo.setStyleSheet(combo_box_stylesheet(config_module.load_readonly().appearance))
        for label, value in _ICON_LOCATIONS:
            self.icon_location_combo.addItem(label, value)
        index = self.icon_location_combo.findData(self._settings.filter_display.filter_icon_location)
        self.icon_location_combo.setCurrentIndex(index if index >= 0 else 0)
        form.addRow("Filter Icons Location:", self.icon_location_combo)

        layout.addWidget(display_group)

        icons_group = CustomGroupBox("Tag Icons")
        icons_layout = icons_group.make_layout(QVBoxLayout)

        add_new_btn = CustomButton("+ Add New")
        add_new_btn.clicked.connect(self._add_new_tag)
        icons_layout.addWidget(add_new_btn)

        scroll = SmoothScrollArea()
        scroll.setWidgetResizable(True)
        rows_container = QWidget()
        self.rows_layout = QVBoxLayout(rows_container)
        self.rows_layout.addStretch(1)
        scroll.setWidget(rows_container)
        icons_layout.addWidget(scroll, stretch=1)
        layout.addWidget(icons_group, stretch=1)

        self._reload_tag_rows()
        return page

    def _add_new_tag(self) -> None:
        from .add_filter_dialog import AddFilterDialog
        dialog = AddFilterDialog(library.all_categories(), parent=self)
        if dialog.exec() == QDialog.Accepted:
            name, category_id = dialog.result_values()
            if name:
                library.create_tag(name)
                if category_id is not None:
                    tag_id = next((tid for tid, tname in library.all_tags_with_ids() if tname == name), None)
                    if tag_id is not None:
                        library.set_tag_category(tag_id, category_id)
                self._reload_tag_rows()

    def _reload_tag_rows(self) -> None:
        for row in self._tag_rows:
            row.setParent(None)
            row.deleteLater()
        self._tag_rows = []
        icons = library.tag_icons()
        outline_colors = library.tag_outline_colors()
        category_ids = library.tag_category_ids()
        categories = library.all_categories()
        for tag_id, tag_name in library.all_tags_with_ids():
            row = _TagIconRow(
                tag_id, tag_name, icons.get(tag_name), category_ids.get(tag_id), categories,
                outline_color=outline_colors.get(tag_name),
            )
            self.rows_layout.insertWidget(self.rows_layout.count() - 1, row)
            self._tag_rows.append(row)

    # ------------------------------------------------------------ Auto Add Filter tab

    def _build_auto_filter_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        info = QLabel(
            "Automatically apply a filter to newly captured clips based on "
            "which application is running. \"While app is open\" applies "
            "whenever a matching process is running at all; \"Only while "
            "app is focused\" applies only if that application had focus "
            "at the moment of capture."
        )
        info.setWordWrap(True)
        info.setStyleSheet("color: gray;")
        layout.addWidget(info)

        scroll = SmoothScrollArea()
        scroll.setWidgetResizable(True)
        rows_container = QWidget()
        self.auto_rows_layout = QVBoxLayout(rows_container)
        self.auto_rows_layout.addStretch(1)
        scroll.setWidget(rows_container)
        layout.addWidget(scroll, stretch=1)

        add_btn = CustomButton("+ Add Rule")
        add_btn.clicked.connect(lambda: self._add_auto_row())
        layout.addWidget(add_btn)

        for rule in self._settings.auto_filters:
            self._add_auto_row(rule.tag_names, rule.app_match, rule.mode)

        return page

    def _add_auto_row(self, tag_names: list[str] | None = None, app_match: str = "", mode: str = "open") -> None:
        row = _AutoFilterRow(tag_names, app_match, mode)
        row.remove_btn.clicked.connect(lambda: self._remove_auto_row(row))
        self.auto_rows_layout.insertWidget(self.auto_rows_layout.count() - 1, row)
        self._auto_rows.append(row)

    def _remove_auto_row(self, row: "_AutoFilterRow") -> None:
        self._auto_rows.remove(row)
        row.setParent(None)
        row.deleteLater()

    def refresh_dynamic_lists(self) -> None:
        """Re-reads the current set of filters from the DB -- called
        whenever Settings becomes visible again (see MainWindow), since
        this page (like the others) is built once at startup and would
        otherwise keep showing whatever filters existed at launch time
        in the tag-icon list and the Auto Add Filter multi-select
        dropdowns."""
        self._reload_tag_rows()
        for row in self._auto_rows:
            row.filter_select.refresh_options()

    # ------------------------------------------------------------ save

    def save(self) -> None:
        """Called by SettingsPage's own Save button -- this page has no
        separate save button of its own, to keep one consistent "Save
        Settings" action for the whole Settings area."""
        settings = config_module.load()
        settings.filter_display.show_filter_names = self.show_names_check.isChecked()
        settings.filter_display.show_filter_icons = self.show_icons_check.isChecked()
        settings.filter_display.filter_icon_location = self.icon_location_combo.currentData()
        settings.auto_filters = [
            row.to_rule() for row in self._auto_rows if row.to_rule().tag_names
        ]
        config_module.save(settings)

        for row in self._tag_rows:
            library.set_tag_icon(row.tag_id, row.icon_path or None)
            outline_text = row.outline_color_edit.text().strip()
            if outline_text and not QColor(outline_text).isValid():
                show_message(
                    self, "Invalid Color",
                    f"'{outline_text}' isn't a valid outline color for '{row.tag_name}' -- "
                    f"use a hex code like #3669a0. Left unchanged.",
                )
                continue
            library.set_tag_outline_color(row.tag_id, outline_text or None)

        self._settings = settings
